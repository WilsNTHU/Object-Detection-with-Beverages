# Nthu-Final-Project-BeverageDetec > 2024-11-29 7:44pm
https://universe.roboflow.com/personal-workspace-kusbp/nthu-final-project-beveragedetec

Provided by a Roboflow user
License: CC BY 4.0

