# ML fianl project > 2024-11-18 4:10pm
https://universe.roboflow.com/project-345hy/ml-fianl-project

Provided by a Roboflow user
License: CC BY 4.0

